PPP RESIN CREATIONS - WEBSITE

FILES
- app.py: Flask website code
- requirements.txt: Python packages for local run and Render deployment
- static/images/: 11 included sample product images

RUN IN VS CODE / PYCHARM
1. Open this folder in VS Code or PyCharm.
2. Open the terminal in this folder.
3. Run: python -m pip install -r requirements.txt
4. Run: python app.py
5. Open: http://127.0.0.1:5000

LOGIN
Username: Resin
Password: 1234

RENDER DEPLOYMENT
Build command: pip install -r requirements.txt
Start command: gunicorn app:app

IMPORTANT
The included images are AI-generated sample product photos, not actual customer/product photographs. Replace them with your own real product photos before advertising. Keep the same filenames in static/images, or update the image names in app.py.

For security before publishing, set SECRET_KEY to a long random value and change the demo login password in app.py.
