
from flask import Flask, render_template_string, request, redirect, session, send_file, url_for
from urllib.parse import quote
from io import BytesIO
import qrcode
import os

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-key-before-public-deployment")

USERNAME = "Resin"
PASSWORD = "1234"
WHATSAPP_NUMBER = "919962007841"

# PRODUCT DETAILS
# Product photos are stored locally inside static/images.
products = [
    {"name": "Alphabet Keychain", "price": 100, "image": "images/alphabet_keychain.jpg"},
    {"name": "Photo Keychain", "price": 280, "image": "images/photo_keychain.jpg"},
    {"name": "Photo Frame", "price": 399, "image": "images/photo_frame.jpg"},
    {"name": "Flower Preservation", "price": 599, "image": "images/flower_preservation.jpg"},
    {"name": "Resin Showpiece", "price": 299, "image": "images/resin_showpiece.jpg"},
    {"name": "Fridge Magnets", "price": 150, "image": "images/fridge_magnet.jpg"},
    {"name": "Resin Bookmarks", "price": 210, "image": "images/resin_bookmark.jpg"},
    {"name": "Resin Wall Clock", "price": 5000, "image": "images/resin_wall_clock.jpg"},
    {"name": "Photo Pyramid", "price": 899, "image": "images/resin_pyramid.jpg"},
    {"name": "Spotify Keychain", "price": 780, "image": "images/spotify_keychain.jpg"},
    {"name": "Spotify Photo Frame", "price": 2000, "image": "images/spotify_frame.jpg"}
]

# QR CODE GENERATOR
def create_qr(data):

    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=10,
        border=4
    )

    qr.add_data(data)
    qr.make(fit=True)

    image = qr.make_image(
        fill_color="#075E54",
        back_color="white"
    )

    image_bytes = BytesIO()
    image.save(image_bytes, format="PNG")
    image_bytes.seek(0)

    return image_bytes


# STATIC WHATSAPP QR CODE
@app.route("/whatsapp_qr.png")
def whatsapp_qr():

    whatsapp_link = "https://wa.me/" + WHATSAPP_NUMBER

    image = create_qr(whatsapp_link)

    return send_file(
        image,
        mimetype="image/png",
        download_name="whatsapp_qrcode.png"
    )


# DYNAMIC ORDER QR CODE
@app.route("/order_qr.png")
def order_qr():

    data = request.args.get("data", "")

    if not data.startswith("https://wa.me/"):
        return "Invalid QR code data", 400

    image = create_qr(data)

    return send_file(
        image,
        mimetype="image/png",
        download_name="PPP_Resin_Order_QR.png"
    )


# MAIN WEBSITE HTML
HTML = """
<!DOCTYPE html>
<html>
<head>

<title>PPP Resin Creations</title>

<meta name="viewport" content="width=device-width, initial-scale=1">

<style>

* {
    box-sizing: border-box;
    scroll-behavior: smooth;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #fff5fa;
    color: #493044;
}

.login {
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    background: linear-gradient(135deg, #ffcce3, #e7caff);
    padding: 20px;
}

.login-box {
    background: white;
    width: 350px;
    max-width: 100%;
    padding: 35px;
    border-radius: 20px;
    text-align: center;
    box-shadow: 0 5px 20px #0002;
}

.login-box h1, .heading {
    color: #b13d79;
}

input, select, textarea {
    width: 100%;
    padding: 12px;
    margin: 10px 0;
    border: 1px solid #e5b4d0;
    border-radius: 8px;
    font-size: 15px;
}

button, .btn {
    background: #b13d79;
    color: white;
    border: none;
    padding: 12px 22px;
    border-radius: 25px;
    cursor: pointer;
    text-decoration: none;
    display: inline-block;
}

button:hover, .btn:hover {
    background: #842657;
}

header {
    background: white;
    padding: 18px 5%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 15px;
    position: sticky;
    top: 0;
    z-index: 10;
    box-shadow: 0 3px 10px #0001;
}

.logo {
    font-size: 27px;
    color: #b13d79;
    font-weight: bold;
}

nav {
    display: flex;
    flex-wrap: wrap;
    gap: 18px;
}

nav a {
    text-decoration: none;
    color: #493044;
    font-weight: bold;
}

nav a:hover {
    color: #d74791;
}

.hero {
    text-align: center;
    padding: 100px 20px;
    background: linear-gradient(120deg, #ffdaeb, #ead9ff);
}

.hero h1 {
    color: #a32e70;
    font-size: 45px;
}

.hero p {
    font-size: 18px;
    line-height: 1.7;
}

section {
    padding: 65px 6%;
    scroll-margin-top: 85px;
}

.heading {
    text-align: center;
    font-size: 32px;
    margin-bottom: 12px;
}

.subtitle {
    text-align: center;
    margin-bottom: 35px;
}

.products {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 25px;
}

.card {
    background: white;
    border-radius: 18px;
    overflow: hidden;
    text-align: center;
    box-shadow: 0 5px 18px #0001;
    transition: 0.3s;
}

.card:hover {
    transform: translateY(-7px);
}

.card img {
    width: 100%;
    height: 240px;
    object-fit: cover;
    background: #f0dce8;
}

.card-content {
    padding: 18px;
}

.card h3 {
    color: #a32e70;
}

.price {
    color: #c33c81;
    font-size: 20px;
    font-weight: bold;
}

.gallery {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
    gap: 20px;
}

.gallery img {
    width: 100%;
    height: 280px;
    object-fit: cover;
    border-radius: 15px;
    background: #f0dce8;
}

.form-box {
    max-width: 650px;
    margin: auto;
    background: white;
    padding: 30px;
    border-radius: 18px;
    box-shadow: 0 5px 15px #0001;
}

.contact {
    text-align: center;
    background: white;
    padding: 30px;
    border-radius: 15px;
    max-width: 650px;
    margin: auto;
}

.contact a {
    color: #b13d79;
}

.qr-box {
    margin: 30px auto;
    background: white;
    padding: 20px;
    border-radius: 15px;
    max-width: 350px;
    box-shadow: 0 5px 15px #0001;
}

.qr-box img {
    width: 240px;
    max-width: 100%;
    display: block;
    margin: 15px auto;
}

.qr-box h3 {
    color: #075E54;
}

.qr-page {
    min-height: 100vh;
    padding: 35px 15px;
    text-align: center;
    background: linear-gradient(135deg, #ffcce3, #e7caff);
}

.qr-card {
    background: white;
    max-width: 480px;
    margin: 25px auto;
    padding: 30px 20px;
    border-radius: 20px;
    box-shadow: 0 5px 20px #0002;
}

.qr-card h1 {
    color: #b13d79;
}

.qr-card img {
    width: 260px;
    max-width: 100%;
    margin: 15px auto;
    display: block;
}

.order-details {
    text-align: left;
    background: #fff5fa;
    padding: 15px;
    border-radius: 10px;
    line-height: 1.8;
    overflow-wrap: anywhere;
}

.whatsapp-btn {
    background: #25D366;
    color: white;
    padding: 13px 22px;
    border-radius: 25px;
    text-decoration: none;
    display: inline-block;
    margin: 8px;
}

footer {
    text-align: center;
    background: #49263d;
    color: white;
    padding: 30px;
}

@media(max-width: 600px) {

    header {
        justify-content: center;
    }

    nav {
        justify-content: center;
        gap: 12px;
    }

    .hero h1 {
        font-size: 32px;
    }

}

</style>
</head>

<body>

{% if qr_page %}

<div class="qr-page">

    <div class="qr-card">

        <h1>PPP RESIN ❤️</h1>

        <h2>Scan to Send Your Order</h2>

        <p>Scan this QR code using your mobile phone.</p>

        <img src="{{ qr_image }}" alt="WhatsApp Order QR Code">

        <h3>Your Order Details</h3>

        <div class="order-details">

            <b>Customer Name:</b> {{ customer }}<br>
            <b>Product:</b> {{ product }}<br>
            <b>Quantity:</b> {{ quantity }}<br>
            <b>Customisation:</b> {{ details }}<br>
            <b>Colour:</b> {{ colour }}

        </div>

        <br>

        <a class="whatsapp-btn"
           href="{{ whatsapp_url }}"
           target="_blank">
            Open WhatsApp Directly
        </a>

        <br>

        <a class="btn" href="/">Back to Website</a>

    </div>

</div>

{% elif not logged_in %}

<div class="login">

    <form class="login-box" method="POST" action="/login">

        <h1>PPP RESIN ❤️</h1>

        <p>Welcome to our handmade resin store!</p>

        {% if error %}
            <p style="color:red">{{ error }}</p>
        {% endif %}

        <input name="username"
               placeholder="Enter Username" required>

        <input name="password"
               type="password"
               placeholder="Enter Password" required>

        <button type="submit">LOGIN</button>

    </form>

</div>

{% else %}

<header>

    <div class="logo">PPP RESIN ✨</div>

    <nav>
        <a href="#home">Home</a>
        <a href="#products">Products</a>
        <a href="#customise">Customise</a>
        <a href="#gallery">Gallery</a>
        <a href="#contact">Contact</a>
        <a href="#order">Order Now</a>
    </nav>

    <a href="/logout">Logout</a>

</header>

<section class="hero" id="home">

    <h1>Welcome to PPP Resin Creations</h1>

    <p>
        Beautiful Handmade Resin Products ❤️<br>
        Special Gifts Made With Love.<br>
        Make Your Memories Forever!
    </p>

    <a href="#products" class="btn">Explore Products</a>

</section>

<section id="products">

    <h2 class="heading">Our Popular Resin Products</h2>

    <p class="subtitle">
        Explore our beautiful handmade collections.
    </p>

    <div class="products">

        {% for p in products %}

        <div class="card">

            <img src="{{ url_for('static', filename=p.image) }}"
                 alt="{{ p.name }}"
                 onerror="this.onerror=null; this.src='https://placehold.co/400x300/f7e4ef/8b3a68?text=PPP+Resin';">

            <div class="card-content">

                <h3>{{ p.name }}</h3>

                <p class="price">₹{{ p.price }}</p>

                <a class="btn"
                   href="#order"
                   onclick="document.getElementById('product').value={{ p.name|tojson }}">
                    Order Now
                </a>

            </div>

        </div>

        {% endfor %}

    </div>

</section>

<section id="customise">

    <h2 class="heading">Customise Your Product</h2>

    <p class="subtitle">
        Create your own personalised resin gift!
    </p>

    <div class="form-box">

        <form action="/whatsapp" method="GET">

            <input type="hidden" name="customer"
                   value="Custom Customer">

            <label>Select Product</label>

            <select name="product">
                {% for p in products %}
                    <option>{{ p.name }}</option>
                {% endfor %}
            </select>

            <label>Enter Name or Letter</label>

            <input name="details"
                   placeholder="Enter your custom details">

            <label>Choose Colour</label>

            <input name="colour"
                   placeholder="Pink, Blue, Gold...">

            <button type="submit">Customise Now</button>

        </form>

    </div>

</section>

<section id="gallery">

    <h2 class="heading">Our Resin Gallery</h2>

    <p class="subtitle">
        Explore our handmade creations.
    </p>

    <div class="gallery">

        {% for p in products %}

            <img src="{{ url_for('static', filename=p.image) }}"
                 alt="{{ p.name }}"
                 onerror="this.onerror=null; this.src='https://placehold.co/400x300/f7e4ef/8b3a68?text=PPP+Resin';">

        {% endfor %}

    </div>

</section>

<section id="contact">

    <h2 class="heading">Contact Us</h2>

    <div class="contact">

        <h3>PPP Resin Creations ❤️</h3>

        <p>Instagram: @ppp_resin</p>

        <p>
            <a href="https://www.instagram.com/ppp_resin/"
               target="_blank">
                Visit Instagram
            </a>
        </p>

        <p>Phone: 9962007841</p>

        <a class="btn"
           href="https://wa.me/919962007841"
           target="_blank">
            Contact on WhatsApp
        </a>

        <div class="qr-box">

            <h3>Scan to Chat on WhatsApp</h3>

            <p>Scan this QR code to contact PPP Resin Creations.</p>

            <img src="{{ url_for('whatsapp_qr') }}"
                 alt="PPP Resin WhatsApp QR Code">

            <a class="btn"
               href="{{ url_for('whatsapp_qr') }}"
               download="PPP_Resin_WhatsApp_QR.png">
                Download QR Code
            </a>

        </div>

    </div>

</section>

<section id="order">

    <h2 class="heading">Order Now ❤️</h2>

    <p class="subtitle">Place your order with us!</p>

    <div class="form-box">

        <form action="/whatsapp" method="GET">

            <label>Your Name</label>

            <input name="customer"
                   placeholder="Enter your name"
                   required>

            <label>Select Product</label>

            <select name="product" id="product">

                {% for p in products %}
                    <option>{{ p.name }}</option>
                {% endfor %}

            </select>

            <label>Quantity</label>

            <input type="number"
                   name="quantity"
                   min="1"
                   value="1"
                   required>

            <label>Customisation Details</label>

            <textarea name="details"
                      rows="4"
                      placeholder="Enter your requirements"></textarea>

            <button type="submit">
                Send Order on WhatsApp
            </button>

        </form>

    </div>

</section>

<footer>

    <h2>PPP RESIN CREATIONS</h2>

    <p>Handmade With Love ❤️</p>

    <p>Instagram: @ppp_resin</p>

    <p>Contact: 9962007841</p>

    <p>© 2026 PPP Resin. All Rights Reserved.</p>

</footer>

{% endif %}

</body>
</html>
"""


# HOME PAGE
@app.route("/")
def home():

    if not session.get("logged_in"):
        return render_template_string(
            HTML,
            logged_in=False,
            qr_page=False,
            error=None,
            products=products
        )

    return render_template_string(
        HTML,
        logged_in=True,
        qr_page=False,
        products=products
    )


# LOGIN PAGE
@app.route("/login", methods=["POST"])
def login():

    username = request.form.get("username")
    password = request.form.get("password")

    if username == USERNAME and password == PASSWORD:

        session["logged_in"] = True
        return redirect("/")

    return render_template_string(
        HTML,
        logged_in=False,
        qr_page=False,
        error="Invalid Username or Password!",
        products=products
    )


# LOGOUT
@app.route("/logout")
def logout():

    session.clear()
    return redirect("/")


# WHATSAPP ORDER - SHOW QR CODE
@app.route("/whatsapp")
def whatsapp():

    if not session.get("logged_in"):
        return redirect("/")

    customer = request.args.get("customer", "")
    product = request.args.get("product", "")
    quantity = request.args.get("quantity", "1")
    details = request.args.get("details", "")
    colour = request.args.get("colour", "")

    # CREATE ORDER MESSAGE
    message = f"""Hello PPP Resin! ❤️

I want to place an order.

Customer Name: {customer}
Product: {product}
Quantity: {quantity}
Customisation: {details}
Colour: {colour}

Please share the order details."""

    # WHATSAPP LINK
    whatsapp_url = (
        "https://wa.me/" + WHATSAPP_NUMBER +
        "?text=" + quote(message)
    )

    # DYNAMIC QR IMAGE LINK
    qr_image = url_for(
        "order_qr",
        data=whatsapp_url
    )

    # DISPLAY QR CODE PAGE
    return render_template_string(
        HTML,
        logged_in=True,
        qr_page=True,
        customer=customer,
        product=product,
        quantity=quantity,
        details=details,
        colour=colour,
        qr_image=qr_image,
        whatsapp_url=whatsapp_url,
        products=products
    )


# RUN WEBSITE
if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)